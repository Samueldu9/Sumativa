# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 11:01:18 2020

@author: samuel
"""

##Pide un caracter al usuario y lo envia por Serial
#Para installar la libreria, ingresar a Anaconda Prompt e ingresar: "pip install pyserial"
import serial

#Iniciar el puerto de serie a 9600 baud
ser = serial.Serial('COM10', 9600)
# entrada = raw_input() para ingresar datos, es como en java scanner.guardar datos que ingresan desde teclado
entrada = input() #Aqui se ingresa w a s d para realizar el movimiento 

while (entrada != 'salir'):
    ser.write(str(entrada).encode())
    print ("He enviado: " + str(entrada))
    entrada = input() #Se continua ingresando 


